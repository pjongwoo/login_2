module.exports = {
    host     : '211.239.124.237',
    user     : 'bizxpress',
    password : 'bizxpress',
    port     : '19603',
    database : 'nodedb'
  };