# Node_Login_Module

1.dbConfig > database.js -> 접속주소 설정

2.npm start *서버 실행
